const { ethers } = require("ethers");
const Token = require("../artifacts/contracts/ICO.sol/ICO.json")
const provider = new ethers.providers.InfuraProvider("ropsten");
const address = "0x27a56092d4acd044285a89649967eD2bB1ebf559"
const signer = new ethers.Wallet("9b7e354c9eb2afc77dbe484907c84014a9d90f63699233a37314dbafaf0f5f5d", provider);
const contract = new ethers.Contract(address, Token.abi, provider)
const contractWithSigner = contract.connect(signer);
let overrides = {
  // To convert Ether to Wei:
  value: ethers.utils.parseEther("0.2")     // ether in this case MUST be a string
};

const main = async () => {
  // await contractWithSigner._setClosingTime(1659312000)
  // const data = await contract.closingTime()
  await contractWithSigner.buyTokens("0xBb8d4f34273Ef13870eBb5f56458D5e63a97dDd0", overrides)
  console.log(data);
  // await contractWithSigner.removeFromLockWhitelist("0xfB11f69093Fe71B72B9650cb4e1775bD89f19EeC")
  // await contractWithSigner.lock()
  // console.log(await contract.lockWhiteList("0xfB11f69093Fe71B72B9650cb4e1775bD89f19EeC"))
  ;
}
main();
